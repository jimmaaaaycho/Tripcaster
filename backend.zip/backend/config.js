export const facebook = {
 clientID: '577108132634988',
 clientSecret: 'cd4652a6b909ad4ef4fbdba60f9dfba8',
 callbackURL: 'http://localhost:3000/auth/facebook/callback',
 profileFields: ['id', 'name', 'displayName', 'picture', 'email'],
};

export const google = {
 clientID: '828305776803-j6c8mkgrvfdbd9od4s8rbjla2utakrud.apps.googleusercontent.com',
 clientSecret: '6yrSfzoW-qf0If8Cip3BIG5m',
 callbackURL: 'http://localhost:3000/auth/google',
};